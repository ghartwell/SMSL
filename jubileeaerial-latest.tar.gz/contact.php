<?php
// require ReCaptcha class
require('recaptcha-master/src/autoload.php');

$from = '"JubileeAerial Contact Form" <noreply@jubileeaerial.com>';
$sendTo = 'gary@ghartwell.com';
$subject = 'New JubileeAerial Message';
$fields = array('name' => 'Name', 'email' => 'Email', 'svcdropdown' => 'Service', 'message' => 'Message');
$okMessage = 'Contact form successfully submitted. Thank you, We will get back to you soon!';
$errorMessage = 'There was an error while submitting the form. Please try again later';
$recaptchaSecret = '6LfaoWgUAAAAANm706p-ALNcVBlPTW_Mz-lyXsTp';


error_reporting(E_ALL & ~E_NOTICE);
// error_reporting(0)

try {
    if (!empty($_POST)) {

     
        if (!isset($_POST['g-recaptcha-response'])) {
            throw new \Exception('ReCaptcha is not set.');
        }

        // do not forget to enter your secret key from https://www.google.com/recaptcha/admin
        
        $recaptcha = new \ReCaptcha\ReCaptcha($recaptchaSecret, new \ReCaptcha\RequestMethod\CurlPost());
        
        // we validate the ReCaptcha field together with the user's IP address
        
        $response = $recaptcha->verify($_POST['g-recaptcha-response'], $_SERVER['REMOTE_ADDR']);

        if (!$response->isSuccess()) {
            throw new \Exception('ReCaptcha was not validated.');
        }
        
        // everything went well, we can compose the message, as usually
        
        $emailText = "You have a new message from your contact form\n=============================\n";

        foreach ($_POST as $key => $value) {
            // If the field exists in the $fields array, include it in the email
            if (isset($fields[$key])) {
                $emailText .= "$fields[$key]: $value\n";
            }
        }
    
        // All the neccessary headers for the email.
        $headers = "From: $from_email" . "\r\n" . "Reply-To: $from_email" . "\r\n" ;
        // $headers = array('Content-Type: text/plain; charset="UTF-8";',
        //     'From: ' . $from,
        //     'Reply-To: ' . $from,
        //     'Return-Path: ' . $from,
        // );
        
        // Send email
        $a = mail($sendTo, $subject, $emailText, implode("\n", $headers));
        if ($a)
                {
                     print("Message was sent, you can send another one");
                } else {
                     print("Message wasn't sent, please check that you have changed emails in the bottom");
                }

        $responseArray = array('type' => 'success', 'message' => $okMessage);
    }
} catch (\Exception $e) {
    $responseArray = array('type' => 'danger', 'message' => $e->getMessage());
}

if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    $encoded = json_encode($responseArray);

    header('Content-Type: application/json');

    echo $encoded;
} else {
    echo $responseArray['message'];
}